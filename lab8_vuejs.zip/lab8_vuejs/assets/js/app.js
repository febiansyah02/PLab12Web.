const { createApp } = Vue;
const { createRouter, createWebHashHistory } = VueRouter;

// Tetap arahkan ke port backend CodeIgniter 4 kamu kemarin
const apiUrl = 'http://localhost:8080';

// 1. Mapping rute URL ke file komponen
const routes = [
    { path: '/', component: Home },
    { path: '/artikel', component: Artikel },
    { path: '/about', component: About } // Rute tugas baru
];

// 2. Inisialisasi instance router
const router = createRouter({
    history: createWebHashHistory(),
    routes
});

// 3. Mount aplikasi Vue menggunakan router
const app = createApp({});
app.use(router);
app.mount('#app');